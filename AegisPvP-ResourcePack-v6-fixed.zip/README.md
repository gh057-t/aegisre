# Aegis PvP Resource Pack - Icon Font

## What this does
Adds your two icons as regular text characters. Any plain string (chat,
scoreboard, tab list, hologram, wherever) that contains these Unicode
characters will render your icon inline with the text - no special API
needed beyond just putting the character in the string:

  \uE001  ->  your info icon
  \uE002  ->  your sword icon

Example, matching the PVPHQ screenshot format:
  "\uE001 Use \uE002 or /duel"
  -> renders as: [info icon] Use [sword icon] or /duel

In Java this is just a normal String, e.g.:
  String line = "\uE001 Use \uE002 or /duel";
  player.sendMessage(line);

These characters are safe to use anywhere: scoreboard line text,
Bukkit/Paper tab list header/footer, chat messages, sign text, item lore,
GUI item names - since they're real Unicode codepoints in the Private Use
Area (E000-F8FF), not special syntax.

## Icon reference
  \uE001  info icon
  \uE002  sword icon
  \uE003  heart icon
  \uE004  gem icon
  \uE005  MVIP badge
  \uE006  VIP badge
  \uE007  TESTER badge
  \uE008  ADMIN badge
  \uE009  AEGIS badge
  \uE00A  MOD badge
  \uE00B  MEDIA badge
  \uE00C  SWORD kit tag icon
  \uE00D  AXE kit tag icon
  \uE00E  MACE kit tag icon
  \uE00F  CPVP kit tag icon
  \uE010  diamond helmet kit tag icon
  \uE011  netherite helmet kit tag icon

The rank badges (\uE005-\uE00B) render bigger than normal text (height 12
vs 8) since they're meant to sit as a name-prefix badge. Everything else
renders at normal text height (8) so it reads inline.

\uE00C-\uE011 are for tags like "/1234 HT1 CPVP" - a small kit icon next
to a tier rank, wherever that display format ends up (tab list, nametag,
chat prefix, etc). These are plain text characters like every other
glyph here - drop them into whatever string builds that display.

Still unmapped: which kit \uE010 (diamond helmet) and \uE011 (netherite
helmet) actually represent - let me know when you land on the exact
tag format and I'll help wire the text-building logic to match.

## Kit icons in the Select Kit GUI
These stay 100% vanilla automatically - no setup needed. The GUI just
shows whatever item is first in each kit's actual loadout, which is
already the plain vanilla item. (There IS an optional /kitadmin seticon
command sitting in the plugin from an earlier version, in case you ever
want a GUI-only reskin later, but it does nothing unless you run it -
ignore it for now.)

## Tuning size/position
Currently: ascent: 7, height: 8 (matches normal text height, sits level
with a normal capital letter). If an icon looks too big/small or
misaligned once you see it in-game:
  - height: bigger number = bigger icon
  - ascent: bigger number = icon sits higher relative to the text baseline
Adjust both files' provider blocks in default.json and re-zip.

## Deploying as a REQUIRED pack (players must accept to join)
1. Host the zip somewhere with a direct download link - a private
   fileserver, S3/R2 bucket, or a GitHub repo using the raw.githubusercontent
   link to the zip (must be a direct file link, not a webpage).
2. Get the SHA1 hash of the zip (needed so the client can verify it
   downloaded correctly):
     certutil -hashfile AegisPvP-ResourcePack.zip SHA1      (Windows)
     shasum -a 1 AegisPvP-ResourcePack.zip                  (Mac/Linux)
3. In Paper's config (config/paper-global.yml under the server root),
   set:
     resource-pack:
       required: true
       resource-pack: "<your direct download URL>"
       hash: "<the SHA1 hash from step 2>"
       prompt-message: "Aegis PvP requires this resource pack to play."
4. Restart the server. Players get prompted on join; declining with
   required:true disconnects them with the prompt message.

If you'd rather prompt instead of hard-require it, set required: false -
players can decline and still play, just without the icons rendering
(they'll see a fallback missing-glyph box or nothing, depending on client
settings, wherever the private-use character shows up).
